import HighchartsReact from "highcharts-react-official";
import highcharts from 'highcharts'
import React, { useEffect, useState } from "react";
import Data from "./Data";

const HighChart=()=>{
    const [dataVal, setDataVal] = useState(Data);
    const [filterData, setFilterData] = useState();
    const [subject, setSubject] = useState('English');
    const [chartType, setChartType] = useState('column')
    let componentMount = true;

    useEffect(()=>{ 
        if(componentMount){
            englishHandler()
        }
        return ()=>{
            componentMount = false;
        }
    },[])
    
    const options = {
        chart:{
            type: chartType
        },
        title: {
          text: 'Student Record'
        },
        accessibility: {
            announceNewData: {
                enabled: true
            }
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            title: {
                text: 'Student record based on Subject'
            },
            max:100
        },
        series: [{
            name: subject,
            colorByPoint: true,
            data: filterData
            // [
            //     {
            //         name: 'Chrome',
            //         y: 63.06,
            //         drilldown: 'Chrome'
            //     },
            //     {
            //         name: 'Safari',
            //         y: 19.84,
            //         drilldown: 'Safari'
            //     },
            // ]
        }]
      }

      const englishHandler=()=>{ 
        const newData1 = Data.map(({english, ...rest})=>({y:english, ...rest}))
        setSubject('English')
        setFilterData(newData1);
      }

      const physicsHandler=()=>{ 
        const newData = Data.map(({physics, ...rest})=>({y:physics, ...rest}))
        setSubject('Physics')
        setFilterData(newData);
      }
      const mathsHandler=()=>{ 
        const newData1 = Data.map(({maths, ...rest})=>({y:maths, ...rest}))
        setSubject('Maths')
        setFilterData(newData1);
      }
    return(
        <div>
            <HighchartsReact
                highcharts={highcharts}
                options={options}
            />
            
            <div className="text-center mb-3">
                <button type="button" className="btn btn-danger me-2" onClick={englishHandler}>English</button>
                <button type="button" className="btn btn-success me-2" onClick={physicsHandler}>Physics</button>
                <button type="button" className="btn btn-info me-2" onClick={mathsHandler}>Maths</button>
            </div>
            <div className="text-center mb-3">
                <button type="button" className="btn btn-primary me-2" onClick={()=>setChartType('column')}>Column Chart</button>
                <button type="button" className="btn btn-primary me-2" onClick={()=>setChartType('bar')}>Bar Chart</button>
                <button type="button" className="btn btn-primary me-2" onClick={()=>setChartType('pie')}>Pie Chart</button>
            </div>
            
            
                <pre>{JSON.stringify(Data, 0,1)}</pre>
        </div>
    )
}

export default HighChart;