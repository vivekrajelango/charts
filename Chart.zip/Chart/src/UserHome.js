import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const UserHome=()=>{
    const [name, setName] = useState()
    const [routeVal, setRouteVal] = useState()
    const location = useLocation();
    const navigate = useNavigate();
    useEffect(()=>{
        if(location.pathname.includes('amanda')){
            setName('Amanda Jones');
            setRouteVal('amanda')
        } else if(location.pathname.includes('ralph')){
            setName('Ralph Thompson')
            setRouteVal('ralph')
        }else if(location.pathname.includes('sarah')){
            setName('Sarah Jane')
            setRouteVal('sarah')
        }
    },[location])
    return(
        <div className="Content">
            <div className="innerContent">
                <h2>Welcome {name} </h2>
                <p>Click on the buttons for chart</p>
            </div>
            <div className="text-center mt-5">
                <button type="button" className="btn btn-outline-info me-2" onClick={()=>navigate(`/${routeVal}/assessment`)} >Assessment</button>
                <button type="button" className="btn btn-outline-info me-2" onClick={()=>navigate(`/${routeVal}/child`)} >Learning </button>
                <button type="button" className="btn btn-outline-info me-2" onClick={()=>navigate(`/${routeVal}/library`)} >Library </button>
            </div>
        </div>
    )
}

export default UserHome