import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import React, {useRef} from 'react';
import { BrowserRouter } from 'react-router-dom';
import AppRoute from './Router';
import { Link } from "react-router-dom";


function App() {
  const mySidenav = useRef();

  const openNav=()=>{
    mySidenav.current.style.width = '200px'
  }
  const closeNav=()=>{
      mySidenav.current.style.width = '0px'
  }
  
  return (
    <div className="App" >
      <BrowserRouter>
      <div ref={mySidenav} id="mySidenav" className="sidenav">
          <a className="closebtn" onClick={closeNav}>&times;</a>
            <Link to='/charts' onClick={closeNav}>Home</Link>
            <Link to='/amanda' onClick={closeNav}>Amanda Jones</Link>
            <Link to='/ralph' onClick={closeNav}>Ralph Thompson</Link>
            <Link to='/sarah' onClick={closeNav}>Sarah Jane</Link>
      </div>
      <div>
          <p className='navBar'  onClick={openNav}>&#9776; All Aboard Learning</p>
      </div>
      <div>
        <AppRoute />
      </div>
      
      </BrowserRouter>
    </div>
  );
}

export default App;
