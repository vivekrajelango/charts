export default [
    {
        "name": "eye_tracking",
            "fail": false,
            "score": 2,
            "fail_reason": "",
            "score_decimal": 1.0,
            "average_time_total": 4006.0,
            "max_possible_score": 2,
            "average_time_correct": 4006.0
    },
    {
        "name": "tricky_words",
            "score": 13,
            "score_decimal": 1.0,
            "average_time_total": 1079.6923076923076,
            "max_possible_score": 13,
            "average_time_correct": 1079.6923076923076
    },
     {
        "name": "nonsense_words",
            "score": 6,
            "score_decimal": 1.0,
            "average_time_total": 1694.0,
            "max_possible_score": 6,
            "average_time_correct": 1694.0
    },
     {
        "name": "grapheme_recognition",
            "score": 24,
            "score_decimal": 1.0,
            "average_time_total": 1080.7916666666667,
            "max_possible_score": 24,
            "average_time_correct": 1080.7916666666667
    },
     {
        "name": "blending",
        "score": 6,
        "score_decimal": 1.0,
        "average_time_total": 402.0,
        "max_possible_score": 6,
        "average_time_correct": 402.0
    },
     {
        "name": "sounding_out",
        "score": 6,
        "score_decimal": 1.0,
        "average_time_total": 3253.0,
        "max_possible_score": 6,
        "average_time_correct": 3253.0
    }
]