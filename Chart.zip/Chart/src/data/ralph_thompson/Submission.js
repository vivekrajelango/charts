export default [
    {
        name: "eye_tracking",
        id: "eye_tracking",
        data: [
            ["Her feet got hurt.", 1],
            ["They cut the long weeds.", 1]
        ]
    },
    {
        name: "tricky_words",
        id: "tricky_words",
        data: [
            ["be", 1],
            ["he", 1],
            ["me", 1],
            ["my", 1],
            ["we", 1],
            ["all", 1],
            ["are", 1],
            ["she", 1],
            ["was", 1],
            ["you", 1],
            ["live", 1],
            ["they", 1],
            ["what", 1]
        ]
    },
    {
        name: "nonsense_words",
        id: "nonsense_words",
        data: [
            ["joo", 1],
            ["var", 1],
            ["woat", 1],
            ["zear", 1],
            ["churk", 1],
            ["shoin", 1],
        ]
    },
    {
        name: "grapheme_recognition",
        id: "grapheme_recognition",
        data: [
            ["j", 1],
            ["v", 1],
            ["w", 1],
            ["x", 1],
            ["y", 1],
            ["z", 1],
            ["ai", 1],
            ["ar", 1],
            ["ch", 1],
            ["ee", 1],
            ["er", 1],
            ["ng", 1],
            ["oa", 1],
            ["oi", 1],
            ["oo", 1],
            ["or", 1],
            ["ow", 1],
            ["qu", 1],
            ["sh", 1],
            ["th", 1],
            ["ur", 1],
            ["air", 1],
            ["ear", 1],
            ["igh", 1]
        ]
    },
    {
        name: "blending",
        id: "blending",
        data: [
            ["jam", 1],
            ["chip", 1],
            ["coin", 1],
            ["feet", 1],
            ["torn", 1],
            ["shark", 1],
        ]
    },
    {
        name: "sounding_out",
        id: "sounding_out",
        data: [
            ["jam", 1],
            ["chip", 1],
            ["coin", 1],
            ["feet", 1],
            ["torn", 1],
            ["shark", 1],
        ]
    },
 ]