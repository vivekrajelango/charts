export default [
    {
        "name": "eye_tracking",
        "fail": false,
        "score": 0,
        "fail_reason": "insufficient_data",
        "score_decimal": 0.0,
        "average_time_total": 40348.0,
        "max_possible_score": 2,
        "average_time_correct": 0.0
    },
    {
        "name": "tricky_words",
        "score": 9,
        "score_decimal": 0.6923076923076923,
        "average_time_total": 3295.6153846153848,
        "max_possible_score": 13,
        "average_time_correct": 2275.0
    },
    {
        "name": "nonsense_words",
        "score": 0,
        "score_decimal": 0.0,
        "average_time_total": 9977.333333333334,
        "max_possible_score": 6,
        "average_time_correct": 0.0
    },
    {
        "name": "grapheme_recognition",
        "score": 24,
        "score_decimal": 1.0,
        "average_time_total": 2060.0416666666665,
        "max_possible_score": 24,
        "average_time_correct": 2060.0416666666665
    },
    {
        "name": "blending",
        "score": 5,
        "score_decimal": 0.8333333333333334,
        "average_time_total": 1471.8333333333333,
        "max_possible_score": 6,
        "average_time_correct": 828.6
    },
    {
        "name": "sounding_out",
        "score": 5,
        "score_decimal": 0.8333333333333334,
        "average_time_total": 7728.5,
        "max_possible_score": 6,
        "average_time_correct": 6653.0
    }
]