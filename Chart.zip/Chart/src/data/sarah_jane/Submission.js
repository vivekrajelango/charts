export default [
    {
        name: "eye_tracking",
        id: "eye_tracking",
        data: [
            ["Her feet got hurt.", 0],
            ["They cut the long weeds.", 0]
        ]
    },
    {
        name: "tricky_words",
        id: "tricky_words",
        data: [
            ["be", 1],
            ["he", 1],
            ["me", 0],
            ["my", 1],
            ["we", 1],
            ["all", 0],
            ["are", 0],
            ["she", 1],
            ["was", 1],
            ["you", 1],
            ["live", 1],
            ["they", 1],
            ["what", 0]
        ]
    },
    {
        name: "nonsense_words",
        id: "nonsense_words",
        data: [
            ["joo", 0],
            ["var", 0],
            ["woat", 0],
            ["zear", 0],
            ["churk", 0],
            ["shoin", 0],
        ]
    },
    {
        name: "grapheme_recognition",
        id: "grapheme_recognition",
        data: [
            ["j", 1],
            ["v", 1],
            ["w", 1],
            ["x", 1],
            ["y", 1],
            ["z", 1],
            ["ai", 1],
            ["ar", 1],
            ["ch", 1],
            ["ee", 1],
            ["er", 1],
            ["ng", 1],
            ["oa", 1],
            ["oi", 1],
            ["oo", 1],
            ["or", 1],
            ["ow", 1],
            ["qu", 1],
            ["sh", 1],
            ["th", 1],
            ["ur", 1],
            ["air", 1],
            ["ear", 1],
            ["igh", 1]
        ]
    },
    {
        name: "blending",
        id: "blending",
        data: [
            ["jam", 1],
            ["chip", 1],
            ["coin", 1],
            ["feet", 1],
            ["torn", 1],
            ["shark", 0],
        ]
    },
    {
        name: "sounding_out",
        id: "sounding_out",
        data: [
            ["jam", 1],
            ["chip", 1],
            ["coin", 1],
            ["feet", 1],
            ["torn", 1],
            ["shark", 0],
        ]
    },
 ]