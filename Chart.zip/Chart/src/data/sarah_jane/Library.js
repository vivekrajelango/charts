export default [
    {
        "name": "natcooks",
        "read_count": 1,
        "last_feedback_value": 5,
        "last_session_timestamp": "2022-11-24T08:28:33.2769080+00:00"
    },
]