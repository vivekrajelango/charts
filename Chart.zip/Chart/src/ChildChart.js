import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts/highmaps";
import timeline from "highcharts/modules/timeline";
import React, { useEffect, useState } from "react";
import Learning from './data/amanda_jones/Learning';
import dateFormat from 'dateformat';
import { Link, useLocation, useNavigate } from "react-router-dom";


timeline(Highcharts);

const ChildChart=()=>{
    const [dataVal, setDataVal] = useState(Learning);
    const [filterData, setFilterData] = useState();
    const [routeVal, setRouteVal] = useState()
    const location = useLocation();
    const navigate = useNavigate();
    let componentMount = true;
    // console.log('Learning', dateFormat("2019-04-30T08:59:00.000Z", "mmmm dS, yyyy"))
    useEffect(()=>{
        if(componentMount){
            getData();
        }
        if(location.pathname.includes('amanda')){
            setRouteVal('amanda')
        } else if(location.pathname.includes('ralph')){
            setRouteVal('ralph')
        }else if(location.pathname.includes('sarah')){
            setRouteVal('sarah')
        }
        return ()=>{
            componentMount = false;
        }
    },[location])

    const getData=()=>{
        const newData1 = dataVal.map(({minigame_id,timestamp})=>({name:minigame_id, description:dateFormat(timestamp, "mmm dd yyyy HH:MM:ss")}))
        // console.log('xx', newData1);
        setFilterData(newData1);
    }
    const options = {
        chart: {
            type: 'timeline'
        },
        accessibility: {
            screenReaderSection: {
                beforeChartFormat: '<h5>{chartTitle}</h5>' +
                    '<div>{typeDescription}</div>' +
                    '<div>{chartSubtitle}</div>' +
                    '<div>{chartLongdesc}</div>' +
                    '<div>{viewTableButton}</div>'
            },
            point: {
                valueDescriptionFormat: '{index}. {point.label}. {point.description}.'
            }
        },
        xAxis: {
            visible: false
        },
        yAxis: {
            visible: false
        },
        title: {
            text: 'Timeline '
        },
        subtitle: {
            text: ''
        },
        colors: [
            '#4185F3',
            '#427CDD',
            '#406AB2',
            '#3E5F8E',
            '#3B4A68',
            '#363C46'
        ],
        series: [{
            data: filterData
        }]
      }
    return(
        <div>
            <div className="text-center">
            <a className="text text-danger me-2" onClick={()=>navigate(`/${routeVal}`)} >Go Back</a>

            </div>
            <HighchartsReact
                highcharts={Highcharts}
                options={options}
            />
            
        </div>
    )
}

export default ChildChart