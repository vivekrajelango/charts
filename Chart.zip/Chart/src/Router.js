import React from "react";
import { Route, Routes, useRoutes } from "react-router-dom";
import ChildChart from "./ChildChart";
import Home from "./Home";
import LibraryTimeLine from "./LibraryTimeLine";
import NewChart from "./NewChart";
import UserHome from "./UserHome";

const AppRoute=()=>{
    return (
        <>
        <Routes >
            <Route path={'/charts'} element={<Home />} />
            <Route path={'/amanda'} element={<UserHome />} />
            <Route path={'/amanda/assessment'} element={<NewChart/>} />
            <Route path={'/amanda/child'} element={<ChildChart/>} />
            <Route path={'/amanda/library'} element={<LibraryTimeLine/>} />
            <Route path={'/ralph'} element={<UserHome />} />
            <Route path={'/ralph/assessment'} element={<NewChart/>} />
            <Route path={'/ralph/child'} element={<ChildChart/>} />
            <Route path={'/ralph/library'} element={<LibraryTimeLine/>} />
            <Route path={'/sarah'} element={<UserHome />} />
            <Route path={'/sarah/assessment'} element={<NewChart/>} />
            <Route path={'/sarah/child'} element={<ChildChart/>} />
            <Route path={'/sarah/library'} element={<LibraryTimeLine/>} />
        </Routes>
        </>
    )
    // let Routes = useRoutes([
    //     {
    //         path:'/',
    //         element: <NewChart />
    //     },
    //     {
    //         path:'/test',
    //         element: <h1>Hello</h1>,
    //         children: {
    //             path: 'test/child',
    //             element: <HighChart />
    //         }
    //     }
    // ])
    // return Routes
}

export default AppRoute