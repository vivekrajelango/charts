import React from "react";
import { useNavigate } from "react-router-dom";

const Home=()=>{
    const navigate = useNavigate();

    return(
        <div className="Content">
            <div className="innerContent">
                <h1>All Aboard Phonics</h1>
                <p>As a teacher, every minute of the day counts.</p>
            </div>
            <div className="text-center mt-5">
                <button type="button" className="btn btn-outline-light me-2" onClick={()=>navigate(`/amanda`)} >Amanda</button>
                <button type="button" className="btn btn-outline-light me-2" onClick={()=>navigate(`/ralph`)} >Ralph</button>
                <button type="button" className="btn btn-outline-light me-2" onClick={()=>navigate(`/sarah`)} >Sarah</button>
            </div>
        </div>
    )
}

export default Home