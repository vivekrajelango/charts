import HighchartsReact from "highcharts-react-official";
import highcharts from 'highcharts';
import Highcharts from "highcharts/highmaps";
import drilldow from "highcharts/modules/drilldown";
import React, { useEffect, useState } from "react";
import Data from "./Data";
import AmandaAssessmentScores from "./data/amanda_jones/AssessmentScores";
import RalphAssessmentScores from './data/ralph_thompson/AssessmentScores';
import SarahAssessmentScores from './data/sarah_jane/AssessmentScores';
import AmandaSubmission from './data/amanda_jones/Submission';
import RalphSubmission from './data/ralph_thompson/Submission';
import SarahSubmission from './data/sarah_jane/Submission';

import { Link, useLocation, useNavigate } from "react-router-dom";

drilldow(Highcharts);

const NewChart=()=>{
    const [dataVal, setDataVal] = useState(AmandaAssessmentScores);
    const [drillDownData, setDrillDownData] = useState(AmandaSubmission);
    const [routeVal, setRouteVal] = useState('amanda')
    const [filterData, setFilterData] = useState();
    const [nameVal, setNameVal] = useState();
    const location = useLocation();
    const navigate = useNavigate();
    let componentMount = true;
    // console.log('Submission', Submission);
    useEffect(()=>{
        if(componentMount){
            if(location.pathname.includes('amanda')){
                setNameVal('Amanda James')
                setRouteVal('amanda')
                setDataVal(AmandaAssessmentScores)
                setDrillDownData(AmandaSubmission)
            } else if(location.pathname.includes('ralph')){
                setNameVal('Ralph Thompson')
                setRouteVal('ralph')
                setDataVal(RalphAssessmentScores)
                setDrillDownData(RalphSubmission)
            }else if(location.pathname.includes('sarah')){
                setNameVal('Sarah Jane')
                setRouteVal('sarah')
                setDataVal(SarahAssessmentScores)
                setDrillDownData(SarahSubmission)
            }
            assesmentHandler();
        }
        return ()=>{
            componentMount = false;
        }
    },[location, dataVal])

    const assesmentHandler=()=>{ 
        const newData1 = dataVal.map(({score, ...rest})=>({y:score, drilldown:rest.name, ...rest}))
        setFilterData(newData1);
        // console.log('filterData', newData1)
      }

    const options = {
        chart:{
            type: 'column'
        },
        title: {
          text: nameVal
        },
        accessibility: {
            announceNewData: {
                enabled: true
            }
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            title: {
                text: 'Score'
            },
            max:25
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    format: '{point.y}'
                }
            }
        },
    
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> correct answers<br/>'
        },
        series: [{
            name: 'Assessment Score',
            colorByPoint: true,
            data: filterData
        }],
        
        drilldown: {
            breadcrumbs: {
                position: {
                    align: 'right'
                }
            },
            max:100,
            series: drillDownData
        }
      }
    return(
        <div>
            <div className="text-center">
                {/* <Link to={'/amanda'} className="text text-danger me-2"> 
                    Go Back
                </Link> */}
                <a className="text text-danger me-2" onClick={()=>navigate(`/${routeVal}`)} >Go Back</a>
            </div>
            <HighchartsReact
                highcharts={Highcharts}
                options={options}
            />
            {/* <div className="text-center mb-3">
            <button type="button" className="btn btn-outline-danger me-2" onClick={()=>navigate(`/${routeVal}/child`)}>Learning Timeline</button>
            <button type="button" className="btn btn-outline-danger me-2" onClick={()=>navigate(`/${routeVal}/library`)}>Library Timeline</button>
            </div> */}
        </div>
    )
}

export default NewChart;