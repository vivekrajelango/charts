import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts/highmaps";
import timeline from "highcharts/modules/timeline";
import React, { useEffect, useState } from "react";
import AmandaLibrary from './data/amanda_jones/Library';
import RalphLibrary from './data/ralph_thompson/Library';
import SarahLibrary from './data/sarah_jane/Library';
import dateFormat from 'dateformat';
import { Link, useLocation, useNavigate } from "react-router-dom";


timeline(Highcharts);

const LibraryTimeLine=()=>{
    const [dataVal, setDataVal] = useState(AmandaLibrary);
    const [filterData, setFilterData] = useState();
    const [routeVal, setRouteVal] = useState('amanda');
    const location = useLocation();
    const navigate = useNavigate();

    let componentMount = true;
    // console.log('Learning', dateFormat("2019-04-30T08:59:00.000Z", "mmmm dS, yyyy"))
    useEffect(()=>{
        if(componentMount){
            if(location.pathname.includes('amanda')){
                setDataVal(AmandaLibrary)
                setRouteVal('amanda')
            } else if(location.pathname.includes('ralph')){
                setDataVal(RalphLibrary)
                setRouteVal('ralph')
            } else if(location.pathname.includes('sarah')){
                setDataVal(SarahLibrary)
                setRouteVal('sarah')
            }
            getData();
        }
    },[location, dataVal])

    const getData=()=>{
        const newData1 = dataVal.map(({name,last_started_timestamp})=>({name:name, description:dateFormat(last_started_timestamp, "mmm dd yyyy HH:MM:ss")}))
        // console.log('xx', newData1);
        setFilterData(newData1);
    }
    const options = {
        chart: {
            type: 'timeline'
        },
        accessibility: {
            screenReaderSection: {
                beforeChartFormat: '<h5>{chartTitle}</h5>' +
                    '<div>{typeDescription}</div>' +
                    '<div>{chartSubtitle}</div>' +
                    '<div>{chartLongdesc}</div>' +
                    '<div>{viewTableButton}</div>'
            },
            point: {
                valueDescriptionFormat: '{index}. {point.label}. {point.description}.'
            }
        },
        xAxis: {
            visible: false
        },
        yAxis: {
            visible: false
        },
        title: {
            text: 'Timeline '
        },
        subtitle: {
            text: ''
        },
        colors: [
            '#4185F3',
            '#427CDD',
            '#406AB2',
            '#3E5A8E',
            '#3B4A68',
            '#363C46'
        ],
        series: [{
            data: filterData
            // [{
            //     name: '2000: Orbiting of an asteroid',
            //     description: '14 February 2000, first orbiting of an asteroid (433 Eros).'
            // }, {
            //     name: '2005: Landing on Titan.',
            //     description: '14 January 2005, first soft landing on Titan also first soft landing in the outer Solar System.'
            // }, {
            //     name: '2011: Orbit of Mercury',
            //     description: '18 March 2011, first spacecraft to orbit Mercury.'
            // }, {
            //     name: '2015: Food eaten in space',
            //     description: '10 August 2015, first food grown in space and eaten (lettuce).'
            // }, {
            //     name: '2019: Black hole photograph',
            //     description: '10 April 2019, first direct photograph of a black hole and its vicinity.'
            // }, {
            //     name: '2020: Private spaceflight',
            //     description: '30 May 2020, first orbital human spaceflight launched by a private company (SpaceX).'
            // }]
        }]
      }
    return(
        <div>
            <div className="text-center">
            <a className="text text-danger me-2" onClick={()=>navigate(`/${routeVal}`)}>Go Back</a>
                {/* <Link to={'/amanda'} className="text text-danger me-2"> 
                    Go Back
                </Link> */}
            </div>
            <HighchartsReact
                highcharts={Highcharts}
                options={options}
            />
            
        </div>
    )
}

export default LibraryTimeLine